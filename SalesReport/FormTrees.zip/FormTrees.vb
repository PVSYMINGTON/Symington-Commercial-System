Public Class FormTrees
    Inherits System.Windows.Forms.Form

    Public filterkeydir As String
    Public filterkeypais As String
    Public filterkeycli As String
    Public filterkeycomp As String
    Public filterkeymarca As String
    Public filterkeytype As String
    Public filterkeygroup As String
    Public filterkeyprod As String
    Public filterkeyAnoCol As String
    Public filterkeyPackage As String
    Public filtergrid As Boolean
    Public filtergrid1 As Boolean
    Public varTabela As String
    Public varDatabase As String
    Public flagWork As Boolean
    Public click1 As Boolean
    Public click2 As Boolean
    Public click3 As Boolean
    Public click4 As Boolean
    Public click5 As Boolean
    Public click6 As Boolean
    Public click7 As Boolean
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    Friend WithEvents TreeView2 As System.Windows.Forms.TreeView
    Friend WithEvents TreeView3 As System.Windows.Forms.TreeView
    Friend WithEvents TreeView4 As System.Windows.Forms.TreeView
    Friend WithEvents TreeView5 As System.Windows.Forms.TreeView
    Friend WithEvents TreeView6 As System.Windows.Forms.TreeView
    Friend WithEvents TreeView7 As System.Windows.Forms.TreeView
    Friend WithEvents image1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Text1 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Command3 As System.Windows.Forms.Button
    Friend WithEvents Command1 As System.Windows.Forms.Button
    Friend WithEvents Command2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents TreeView8 As System.Windows.Forms.TreeView
    Friend WithEvents TreeView9 As System.Windows.Forms.TreeView
    Friend WithEvents TreeView10 As System.Windows.Forms.TreeView
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FormTrees))
        Me.TreeView1 = New System.Windows.Forms.TreeView
        Me.TreeView2 = New System.Windows.Forms.TreeView
        Me.TreeView3 = New System.Windows.Forms.TreeView
        Me.TreeView4 = New System.Windows.Forms.TreeView
        Me.TreeView5 = New System.Windows.Forms.TreeView
        Me.TreeView6 = New System.Windows.Forms.TreeView
        Me.TreeView7 = New System.Windows.Forms.TreeView
        Me.Command3 = New System.Windows.Forms.Button
        Me.image1 = New System.Windows.Forms.PictureBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Text1 = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Command1 = New System.Windows.Forms.Button
        Me.Command2 = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.TreeView8 = New System.Windows.Forms.TreeView
        Me.TreeView9 = New System.Windows.Forms.TreeView
        Me.TreeView10 = New System.Windows.Forms.TreeView
        Me.SuspendLayout()
        '
        'TreeView1
        '
        Me.TreeView1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TreeView1.BackColor = System.Drawing.Color.BurlyWood
        Me.TreeView1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TreeView1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView1.HideSelection = False
        Me.TreeView1.ImageIndex = -1
        Me.TreeView1.ItemHeight = 14
        Me.TreeView1.Location = New System.Drawing.Point(60, 72)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.SelectedImageIndex = -1
        Me.TreeView1.Size = New System.Drawing.Size(120, 208)
        Me.TreeView1.TabIndex = 0
        '
        'TreeView2
        '
        Me.TreeView2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TreeView2.BackColor = System.Drawing.Color.BurlyWood
        Me.TreeView2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TreeView2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView2.HideSelection = False
        Me.TreeView2.ImageIndex = -1
        Me.TreeView2.ItemHeight = 14
        Me.TreeView2.Location = New System.Drawing.Point(188, 72)
        Me.TreeView2.Name = "TreeView2"
        Me.TreeView2.SelectedImageIndex = -1
        Me.TreeView2.Size = New System.Drawing.Size(248, 208)
        Me.TreeView2.TabIndex = 1
        '
        'TreeView3
        '
        Me.TreeView3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TreeView3.BackColor = System.Drawing.Color.BurlyWood
        Me.TreeView3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TreeView3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView3.HideSelection = False
        Me.TreeView3.ImageIndex = -1
        Me.TreeView3.ItemHeight = 14
        Me.TreeView3.Location = New System.Drawing.Point(444, 72)
        Me.TreeView3.Name = "TreeView3"
        Me.TreeView3.SelectedImageIndex = -1
        Me.TreeView3.Size = New System.Drawing.Size(272, 208)
        Me.TreeView3.TabIndex = 2
        '
        'TreeView4
        '
        Me.TreeView4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TreeView4.BackColor = System.Drawing.Color.BurlyWood
        Me.TreeView4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TreeView4.CheckBoxes = True
        Me.TreeView4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView4.HideSelection = False
        Me.TreeView4.ImageIndex = -1
        Me.TreeView4.ItemHeight = 14
        Me.TreeView4.Location = New System.Drawing.Point(724, 72)
        Me.TreeView4.Name = "TreeView4"
        Me.TreeView4.SelectedImageIndex = -1
        Me.TreeView4.Size = New System.Drawing.Size(232, 208)
        Me.TreeView4.TabIndex = 3
        '
        'TreeView5
        '
        Me.TreeView5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TreeView5.BackColor = System.Drawing.Color.BurlyWood
        Me.TreeView5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TreeView5.CheckBoxes = True
        Me.TreeView5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView5.HideSelection = False
        Me.TreeView5.ImageIndex = -1
        Me.TreeView5.ItemHeight = 14
        Me.TreeView5.Location = New System.Drawing.Point(8, 288)
        Me.TreeView5.Name = "TreeView5"
        Me.TreeView5.SelectedImageIndex = -1
        Me.TreeView5.Size = New System.Drawing.Size(168, 208)
        Me.TreeView5.TabIndex = 4
        '
        'TreeView6
        '
        Me.TreeView6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TreeView6.BackColor = System.Drawing.Color.BurlyWood
        Me.TreeView6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TreeView6.CheckBoxes = True
        Me.TreeView6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView6.HideSelection = False
        Me.TreeView6.ImageIndex = -1
        Me.TreeView6.ItemHeight = 14
        Me.TreeView6.Location = New System.Drawing.Point(184, 288)
        Me.TreeView6.Name = "TreeView6"
        Me.TreeView6.SelectedImageIndex = -1
        Me.TreeView6.Size = New System.Drawing.Size(144, 208)
        Me.TreeView6.TabIndex = 5
        '
        'TreeView7
        '
        Me.TreeView7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TreeView7.BackColor = System.Drawing.Color.BurlyWood
        Me.TreeView7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TreeView7.CheckBoxes = True
        Me.TreeView7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView7.HideSelection = False
        Me.TreeView7.ImageIndex = -1
        Me.TreeView7.ItemHeight = 14
        Me.TreeView7.Location = New System.Drawing.Point(336, 288)
        Me.TreeView7.Name = "TreeView7"
        Me.TreeView7.SelectedImageIndex = -1
        Me.TreeView7.Size = New System.Drawing.Size(136, 208)
        Me.TreeView7.TabIndex = 6
        '
        'Command3
        '
        Me.Command3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Command3.Image = CType(resources.GetObject("Command3.Image"), System.Drawing.Image)
        Me.Command3.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Command3.Location = New System.Drawing.Point(935, 0)
        Me.Command3.Name = "Command3"
        Me.Command3.Size = New System.Drawing.Size(72, 56)
        Me.Command3.TabIndex = 8
        Me.Command3.Text = "Back..."
        Me.Command3.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'image1
        '
        Me.image1.Image = CType(resources.GetObject("image1.Image"), System.Drawing.Image)
        Me.image1.Location = New System.Drawing.Point(0, 0)
        Me.image1.Name = "image1"
        Me.image1.Size = New System.Drawing.Size(150, 69)
        Me.image1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.image1.TabIndex = 8
        Me.image1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 16.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(168, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "By Month"
        '
        'Text1
        '
        Me.Text1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Text1.BackColor = System.Drawing.Color.BurlyWood
        Me.Text1.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower
        Me.Text1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text1.Location = New System.Drawing.Point(356, 514)
        Me.Text1.Name = "Text1"
        Me.Text1.Size = New System.Drawing.Size(304, 21)
        Me.Text1.TabIndex = 7
        Me.Text1.Text = ""
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label2.Font = New System.Drawing.Font("Arial", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(188, 512)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(152, 24)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Filter Products..."
        '
        'Command1
        '
        Me.Command1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Command1.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Command1.Image = CType(resources.GetObject("Command1.Image"), System.Drawing.Image)
        Me.Command1.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Command1.Location = New System.Drawing.Point(791, 0)
        Me.Command1.Name = "Command1"
        Me.Command1.Size = New System.Drawing.Size(72, 56)
        Me.Command1.TabIndex = 12
        Me.Command1.Text = "Client Report"
        Me.Command1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'Command2
        '
        Me.Command2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Command2.Image = CType(resources.GetObject("Command2.Image"), System.Drawing.Image)
        Me.Command2.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Command2.Location = New System.Drawing.Point(863, 0)
        Me.Command2.Name = "Command2"
        Me.Command2.Size = New System.Drawing.Size(72, 56)
        Me.Command2.TabIndex = 13
        Me.Command2.Text = "All Data"
        Me.Command2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button1.Location = New System.Drawing.Point(719, 56)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(72, 56)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "Package"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button1.Visible = False
        '
        'Button2
        '
        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button2.Location = New System.Drawing.Point(719, 112)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(72, 56)
        Me.Button2.TabIndex = 15
        Me.Button2.Text = "Product"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button2.Visible = False
        '
        'Button3
        '
        Me.Button3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button3.Location = New System.Drawing.Point(719, 168)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(72, 56)
        Me.Button3.TabIndex = 16
        Me.Button3.Text = "Market"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button3.Visible = False
        '
        'Button4
        '
        Me.Button4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button4.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Image = CType(resources.GetObject("Button4.Image"), System.Drawing.Image)
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button4.Location = New System.Drawing.Point(719, 0)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(72, 56)
        Me.Button4.TabIndex = 17
        Me.Button4.Text = "Group Report"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button4.Visible = False
        '
        'TreeView8
        '
        Me.TreeView8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TreeView8.BackColor = System.Drawing.Color.BurlyWood
        Me.TreeView8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TreeView8.CheckBoxes = True
        Me.TreeView8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView8.HideSelection = False
        Me.TreeView8.ImageIndex = -1
        Me.TreeView8.ItemHeight = 14
        Me.TreeView8.Location = New System.Drawing.Point(480, 288)
        Me.TreeView8.Name = "TreeView8"
        Me.TreeView8.SelectedImageIndex = -1
        Me.TreeView8.Size = New System.Drawing.Size(192, 208)
        Me.TreeView8.TabIndex = 18
        '
        'TreeView9
        '
        Me.TreeView9.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TreeView9.BackColor = System.Drawing.Color.BurlyWood
        Me.TreeView9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TreeView9.CheckBoxes = True
        Me.TreeView9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView9.HideSelection = False
        Me.TreeView9.ImageIndex = -1
        Me.TreeView9.ItemHeight = 14
        Me.TreeView9.Location = New System.Drawing.Point(680, 288)
        Me.TreeView9.Name = "TreeView9"
        Me.TreeView9.SelectedImageIndex = -1
        Me.TreeView9.Size = New System.Drawing.Size(120, 208)
        Me.TreeView9.TabIndex = 19
        '
        'TreeView10
        '
        Me.TreeView10.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TreeView10.BackColor = System.Drawing.Color.BurlyWood
        Me.TreeView10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TreeView10.CheckBoxes = True
        Me.TreeView10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView10.HideSelection = False
        Me.TreeView10.ImageIndex = -1
        Me.TreeView10.ItemHeight = 14
        Me.TreeView10.Location = New System.Drawing.Point(808, 288)
        Me.TreeView10.Name = "TreeView10"
        Me.TreeView10.SelectedImageIndex = -1
        Me.TreeView10.Size = New System.Drawing.Size(192, 208)
        Me.TreeView10.TabIndex = 20
        '
        'FormTrees
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.DarkKhaki
        Me.ClientSize = New System.Drawing.Size(1008, 573)
        Me.ControlBox = False
        Me.Controls.Add(Me.TreeView10)
        Me.Controls.Add(Me.TreeView9)
        Me.Controls.Add(Me.TreeView8)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Command2)
        Me.Controls.Add(Me.Command1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Text1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.image1)
        Me.Controls.Add(Me.Command3)
        Me.Controls.Add(Me.TreeView7)
        Me.Controls.Add(Me.TreeView6)
        Me.Controls.Add(Me.TreeView5)
        Me.Controls.Add(Me.TreeView4)
        Me.Controls.Add(Me.TreeView3)
        Me.Controls.Add(Me.TreeView2)
        Me.Controls.Add(Me.TreeView1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "FormTrees"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Choose Criteria"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub FormTrees_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Top = 0
        Me.Left = 0
        Me.Width = Me.MdiParent.ClientSize.Width - 4
        Me.Height = Me.MdiParent.ClientSize.Height - 4
        click1 = False
        filterkeydir = "%"
        filterkeypais = "%"
        filterkeycli = "%"
        filterkeycomp = "Company like '%'"
        filterkeymarca = "Marca like '%'"
        filterkeytype = "Tipo like '%'"
        filterkeygroup = "Grupo like '%'"
        filterkeyprod = "Subcat Like '%'"
        filterkeyAnoCol = "Anocol like '%'"
        filterkeyPackage = "embalagem like '%'"

        If varTabela = "vendasportohistfull" Then Button4.Visible = True

        treefill(-1)


    End Sub
    Private Sub treefill(ByVal Index As Integer)



        TreeView1.BeginUpdate()
        TreeView2.BeginUpdate()
        TreeView3.BeginUpdate()
        TreeView4.BeginUpdate()
        TreeView5.BeginUpdate()
        TreeView6.BeginUpdate()
        TreeView7.BeginUpdate()
        TreeView8.BeginUpdate()
        TreeView9.BeginUpdate()
        TreeView10.BeginUpdate()


        filtergrid = False
        Cursor.Current = Cursors.WaitCursor

        Dim x As Integer

        If Index < 0 Then TreeView1.Nodes.Clear()
        If Index < 1 Then TreeView2.Nodes.Clear()
        If Index < 2 Then TreeView3.Nodes.Clear()
        If Index < 3 Then TreeView4.Nodes.Clear()
        If Index < 4 Then TreeView5.Nodes.Clear()
        If Index < 5 Then TreeView6.Nodes.Clear()
        If Index < 6 Then TreeView7.Nodes.Clear()
        If Index < 7 Then TreeView8.Nodes.Clear()
        If Index < 8 Then TreeView9.Nodes.Clear()
        If Index < 9 Then TreeView10.Nodes.Clear()

        Dim Connection As New ADODB.Connection              ' Use ADO for the connection
        Dim rs As New ADODB.Recordset
        With rs

            ' Open the connection
            'Connection.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Persist Security Info=False;Data Source=c:\sales\dados\vendasportomes.mdb;Mode=Read"
            Connection.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Persist Security Info=False;Data Source=" & varDatabase & ";Mode=Read"
            Connection.Open()


            ' Get all the records from our data tables
            If Index < 0 Then

                .Open("Select distinct director from " & varTabela, Connection, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
                AddNodes(rs, "Market Director", 0)
                .Close()
            End If
            If Index < 1 Then
                .Open("Select distinct pais from " & varTabela & " where director like '" & filterkeydir _
                & "' and pais like '" & filterkeypais & "' and cliente like '" & filterkeycli _
                & "' and (" & filterkeycomp & ") and (" & filterkeytype & ") and (" & filterkeymarca _
                & ") and (" & filterkeygroup & ") and (" & filterkeyprod _
                & ") and (" & filterkeyAnoCol & ") and (" & filterkeyPackage & ")" _
                , Connection, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
                AddNodes(rs, "Market", 1)
                .Close()
            End If

            If Index < 2 Then
                .Open("Select distinct cliente from " & varTabela & " where director like '" & filterkeydir _
                & "' and pais like '" & filterkeypais & "' and cliente like '" & filterkeycli _
                & "' and (" & filterkeycomp & ") and (" & filterkeytype & ") and (" & filterkeymarca _
                & ") and (" & filterkeygroup & ") and (" & filterkeyprod _
                & ") and (" & filterkeyAnoCol & ") and (" & filterkeyPackage & ")" _
                , Connection, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
                AddNodes(rs, "Client", 2)
                .Close()
            End If

            If Index < 3 Then
                .Open("Select distinct company from " & varTabela & " where director like '" & filterkeydir _
                & "' and pais like '" & filterkeypais & "' and cliente like '" & filterkeycli _
                & "' and (" & filterkeycomp & ") and (" & filterkeytype & ") and (" & filterkeymarca _
                & ") and (" & filterkeygroup & ") and (" & filterkeyprod _
                & ") and (" & filterkeyAnoCol & ") and (" & filterkeyPackage & ")" _
                , Connection, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
                AddNodes(rs, "Company", 3)
                .Close()
            End If

            If Index < 4 Then
                .Open("Select distinct tipo from " & varTabela & " where director like '" & filterkeydir _
                & "' and pais like '" & filterkeypais & "' and cliente like '" & filterkeycli _
                & "' and (" & filterkeycomp & ") and (" & filterkeytype & ") and (" & filterkeymarca _
                & ") and (" & filterkeygroup & ") and (" & filterkeyprod _
                & ") and (" & filterkeyAnoCol & ") and (" & filterkeyPackage & ")" _
                , Connection, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
                AddNodes(rs, "Type", 4)
                .Close()
            End If

            If Index < 5 Then
                .Open("Select distinct marca from " & varTabela & " where director like '" & filterkeydir _
                & "' and pais like '" & filterkeypais & "' and cliente like '" & filterkeycli _
                & "' and (" & filterkeycomp & ") and (" & filterkeytype & ") and (" & filterkeymarca _
                & ") and (" & filterkeygroup & ") and (" & filterkeyprod _
                & ") and (" & filterkeyAnoCol & ") and (" & filterkeyPackage & ")" _
                , Connection, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
                AddNodes(rs, "Trademark", 5)
                .Close()
            End If

            If Index < 6 Then
                .Open("Select distinct grupo from " & varTabela & " where director like '" & filterkeydir _
                & "' and pais like '" & filterkeypais & "' and cliente like '" & filterkeycli _
                            & "' and (" & filterkeycomp & ") and (" & filterkeytype & ") and (" & filterkeymarca _
                            & ") and (" & filterkeygroup & ") and (" & filterkeyprod _
                            & ") and (" & filterkeyAnoCol & ") and (" & filterkeyPackage & ")" _
                            , Connection, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
                AddNodes(rs, "Group", 6)
                .Close()
            End If
            If Index < 7 Then
                .Open("Select subcat from " & varTabela & " where director like '" & filterkeydir _
               & "' and pais like '" & filterkeypais & "' and cliente like '" & filterkeycli _
                & "' and (" & filterkeycomp & ") and (" & filterkeytype & ") and (" & filterkeymarca _
                & ") and (" & filterkeygroup & ") and (" & filterkeyprod _
                & ") and (" & filterkeyAnoCol & ") and (" & filterkeyPackage & ") GROUP BY Subcat ORDER BY First(SubcatID) " _
                , Connection, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
                AddNodes(rs, "Subcat", 7)
                .Close()
            End If
            If Index < 8 Then
                .Open("Select distinct AnoCol from " & varTabela & " where director like '" & filterkeydir _
               & "' and pais like '" & filterkeypais & "' and cliente like '" & filterkeycli _
                & "' and (" & filterkeycomp & ") and (" & filterkeytype & ") and (" & filterkeymarca _
                & ") and (" & filterkeygroup & ") and (" & filterkeyprod _
                & ") and (" & filterkeyAnoCol & ") and (" & filterkeyPackage & ")" _
                , Connection, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
                AddNodes(rs, "VintageYear", 8)
                .Close()
            End If
            If Index < 9 Then
                .Open("Select distinct embalagem from " & varTabela & " where director like '" & filterkeydir _
               & "' and pais like '" & filterkeypais & "' and cliente like '" & filterkeycli _
                & "' and (" & filterkeycomp & ") and (" & filterkeytype & ") and (" & filterkeymarca _
                & ") and (" & filterkeygroup & ") and (" & filterkeyprod _
                & ") and (" & filterkeyAnoCol & ") and (" & filterkeyPackage & ")" _
                , Connection, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
                AddNodes(rs, "Package", 9)
                .Close()
            End If
            ' Cleanup
        End With
        Connection.Close()
        rs = Nothing
        Connection = Nothing
        TreeView1.Nodes(0).Expand()
        TreeView2.Nodes(0).Expand()
        TreeView3.Nodes(0).Expand()
        TreeView4.Nodes(0).Expand()
        TreeView5.Nodes(0).Expand()
        TreeView6.Nodes(0).Expand()
        TreeView7.Nodes(0).Expand()
        TreeView8.Nodes(0).Expand()
        TreeView9.Nodes(0).Expand()
        TreeView10.Nodes(0).Expand()


        If Index = -1 Then
            TreeView1.SelectedNode = TreeView1.Nodes(0).Nodes(0)
            '  TreeView2.SelectedNode = TreeView2.Nodes(0).Nodes(0)
            '  TreeView3.SelectedNode = TreeView3.Nodes(0).Nodes(0)
            '  TreeView4.Nodes(0).Nodes(0).Checked = True
            '  TreeView5.Nodes(0).Nodes(0).Checked = True
            '  TreeView6.Nodes(0).Nodes(0).Checked = True
            '  TreeView7.Nodes(0).Nodes(0).Checked = True
            '  TreeView8.Nodes(0).Nodes(0).Checked = True
            '  TreeView9.Nodes(0).Nodes(0).Checked = True
            '  TreeView10.Nodes(0).Nodes(0).Checked = True

        End If
        If Index = 0 Then
            TreeView2.SelectedNode = TreeView2.Nodes(0).Nodes(0)
            ' TreeView3.SelectedNode = TreeView3.Nodes(0).Nodes(0)
            ' TreeView4.Nodes(0).Nodes(0).Checked = True
            ' TreeView5.Nodes(0).Nodes(0).Checked = True
            'TreeView6.Nodes(0).Nodes(0).Checked = True
            'TreeView7.Nodes(0).Nodes(0).Checked = True
            'TreeView8.Nodes(0).Nodes(0).Checked = True
            'TreeView9.Nodes(0).Nodes(0).Checked = True
            'TreeView10.Nodes(0).Nodes(0).Checked = True
        End If
        If Index = 1 Then
            TreeView3.SelectedNode = TreeView3.Nodes(0).Nodes(0)
            'TreeView4.Nodes(0).Nodes(0).Checked = True
            'TreeView5.Nodes(0).Nodes(0).Checked = True
            'TreeView6.Nodes(0).Nodes(0).Checked = True
            'TreeView7.Nodes(0).Nodes(0).Checked = True
            'TreeView8.Nodes(0).Nodes(0).Checked = True
            'TreeView9.Nodes(0).Nodes(0).Checked = True
            'TreeView10.Nodes(0).Nodes(0).Checked = True
        End If
        If Index = 2 Then
            TreeView4.Nodes(0).Nodes(0).Checked = True
            'TreeView5.Nodes(0).Nodes(0).Checked = True
            'TreeView6.Nodes(0).Nodes(0).Checked = True
            'TreeView7.Nodes(0).Nodes(0).Checked = True
            'TreeView8.Nodes(0).Nodes(0).Checked = True
            'TreeView9.Nodes(0).Nodes(0).Checked = True
            'TreeView10.Nodes(0).Nodes(0).Checked = True
        End If
        If Index = 3 Then
            TreeView5.Nodes(0).Nodes(0).Checked = True
            'TreeView6.Nodes(0).Nodes(0).Checked = True
            'TreeView7.Nodes(0).Nodes(0).Checked = True
            'TreeView8.Nodes(0).Nodes(0).Checked = True
            'TreeView9.Nodes(0).Nodes(0).Checked = True
            'TreeView10.Nodes(0).Nodes(0).Checked = True
        End If
        If Index = 4 Then
            TreeView6.Nodes(0).Nodes(0).Checked = True
            'TreeView7.Nodes(0).Nodes(0).Checked = True
            'TreeView8.Nodes(0).Nodes(0).Checked = True
            'TreeView9.Nodes(0).Nodes(0).Checked = True
            'TreeView10.Nodes(0).Nodes(0).Checked = True
        End If
        If Index = 5 Then
            TreeView7.Nodes(0).Nodes(0).Checked = True
            'TreeView8.Nodes(0).Nodes(0).Checked = True
            'TreeView9.Nodes(0).Nodes(0).Checked = True
            'TreeView10.Nodes(0).Nodes(0).Checked = True
        End If
        If Index = 6 Then

            TreeView8.Nodes(0).Nodes(0).Checked = True
            'TreeView9.Nodes(0).Nodes(0).Checked = True
            'TreeView10.Nodes(0).Nodes(0).Checked = True
        End If
        If Index = 7 Then
            TreeView9.Nodes(0).Nodes(0).Checked = True
            'TreeView10.Nodes(0).Nodes(0).Checked = True
        End If
        If Index = 8 Then
            TreeView10.Nodes(0).Nodes(0).Checked = True
        End If

        TreeView1.EndUpdate()
        TreeView2.EndUpdate()
        TreeView3.EndUpdate()
        TreeView4.EndUpdate()
        TreeView5.EndUpdate()
        TreeView6.EndUpdate()
        TreeView7.EndUpdate()
        TreeView8.EndUpdate()
        TreeView9.EndUpdate()
        TreeView10.EndUpdate()

        Me.Cursor = Cursors.Default
        flagWork = False

    End Sub
    Private Sub AddNodes(ByVal rs As ADODB.Recordset, ByVal nome As String, ByVal t As Integer)

        Dim s As String
        Dim nodxA As TreeNode
        Dim nodx As TreeNode

        Select Case t
            Case 0

                With TreeView1.Nodes
                    nodxA = .Add(nome)
                    nodxA.Tag = nome
                    nodxA.EnsureVisible()
                    nodx = TreeView1.Nodes(nodxA.Index).Nodes.Add("ALL")
                    s = vbNullString
                    While Not rs.EOF
                        On Error Resume Next
                        If rs.Fields(0).Value <> s Then
                            nodx = TreeView1.Nodes(nodxA.Index).Nodes.Add(rs.Fields(0).Value)
                        End If
                        rs.MoveNext()
                    End While
                End With
            Case 1
                With TreeView2

                    nodxA = .Nodes.Add(nome)
                    nodxA.Tag = nome
                    nodxA.EnsureVisible()
                    nodx = .Nodes(nodxA.Index).Nodes.Add("ALL")
                    s = vbNullString
                    While Not rs.EOF
                        'On Error Resume Next
                        If rs.Fields(0).Value <> s Then
                            nodx = .Nodes(nodxA.Index).Nodes.Add(rs.Fields(0).Value)
                        End If
                        rs.MoveNext()
                    End While
                End With
            Case 2
                With TreeView3

                    nodxA = .Nodes.Add(nome)
                    nodxA.Tag = nome
                    nodxA.EnsureVisible()
                    nodx = .Nodes(nodxA.Index).Nodes.Add("ALL")
                    s = vbNullString
                    While Not rs.EOF
                        'On Error Resume Next
                        If rs.Fields(0).Value <> s Then
                            nodx = .Nodes(nodxA.Index).Nodes.Add(rs.Fields(0).Value)
                        End If
                        rs.MoveNext()
                    End While
                End With
            Case 3
                With TreeView4

                    nodxA = .Nodes.Add(nome)
                    nodxA.Tag = nome
                    nodxA.EnsureVisible()
                    nodx = .Nodes(nodxA.Index).Nodes.Add("ALL")
                    s = vbNullString
                    While Not rs.EOF
                        'On Error Resume Next
                        If rs.Fields(0).Value <> s Then
                            nodx = .Nodes(nodxA.Index).Nodes.Add(rs.Fields(0).Value)
                        End If
                        rs.MoveNext()
                    End While
                End With
            Case 4
                With TreeView5

                    nodxA = .Nodes.Add(nome)
                    nodxA.Tag = nome
                    nodxA.EnsureVisible()
                    nodx = .Nodes(nodxA.Index).Nodes.Add("ALL")
                    s = vbNullString
                    While Not rs.EOF
                        'On Error Resume Next
                        If rs.Fields(0).Value <> s Then
                            nodx = .Nodes(nodxA.Index).Nodes.Add(rs.Fields(0).Value)
                        End If
                        rs.MoveNext()
                    End While
                End With
            Case 5
                With TreeView6

                    nodxA = .Nodes.Add(nome)
                    nodxA.Tag = nome
                    nodxA.EnsureVisible()
                    nodx = .Nodes(nodxA.Index).Nodes.Add("ALL")
                    s = vbNullString
                    While Not rs.EOF
                        'On Error Resume Next
                        If rs.Fields(0).Value <> s Then
                            nodx = .Nodes(nodxA.Index).Nodes.Add(rs.Fields(0).Value)
                        End If
                        rs.MoveNext()
                    End While
                End With
            Case 6
                With TreeView7

                    nodxA = .Nodes.Add(nome)
                    nodxA.Tag = nome
                    nodxA.EnsureVisible()
                    nodx = .Nodes(nodxA.Index).Nodes.Add("ALL")
                    s = vbNullString
                    While Not rs.EOF
                        'On Error Resume Next
                        If rs.Fields(0).Value <> s Then
                            nodx = .Nodes(nodxA.Index).Nodes.Add(rs.Fields(0).Value)
                        End If
                        rs.MoveNext()
                    End While
                End With
            Case 7
                With TreeView8

                    nodxA = .Nodes.Add(nome)
                    nodxA.Tag = nome
                    nodxA.EnsureVisible()
                    nodx = .Nodes(nodxA.Index).Nodes.Add("ALL")
                    s = vbNullString
                    While Not rs.EOF
                        'On Error Resume Next
                        If rs.Fields(0).Value <> s Then
                            nodx = .Nodes(nodxA.Index).Nodes.Add(rs.Fields(0).Value)
                        End If
                        rs.MoveNext()
                    End While
                End With
            Case 8
                With TreeView9

                    nodxA = .Nodes.Add(nome)
                    nodxA.Tag = nome
                    nodxA.EnsureVisible()
                    nodx = .Nodes(nodxA.Index).Nodes.Add("ALL")
                    s = vbNullString
                    While Not rs.EOF
                        'On Error Resume Next
                        If rs.Fields(0).Value <> s Then
                            nodx = .Nodes(nodxA.Index).Nodes.Add(rs.Fields(0).Value)
                        End If
                        rs.MoveNext()
                    End While
                End With
            Case 9
                With TreeView10

                    nodxA = .Nodes.Add(nome)
                    nodxA.Tag = nome
                    nodxA.EnsureVisible()
                    nodx = .Nodes(nodxA.Index).Nodes.Add("ALL")
                    s = vbNullString
                    While Not rs.EOF
                        'On Error Resume Next
                        If rs.Fields(0).Value <> s Then
                            nodx = .Nodes(nodxA.Index).Nodes.Add(rs.Fields(0).Value)
                        End If
                        rs.MoveNext()
                    End While
                End With
        End Select
    End Sub
    Private Sub Command1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Command1.Click
        filtergrid = False
        Cursor.Current = Cursors.WaitCursor
        Select Case varTabela
            Case "vendasportomesfull"
                Me.SuspendLayout()
                Dim formgrid As New FormGridPortoMes
                With formgrid
                    .vardatabase = varDatabase
                    .vartabela = "vendasportomesfull"
                    .filterkeydir = filterkeydir
                    .filterkeypais = filterkeypais
                    .filterkeycli = filterkeycli
                    .filterkeycomp = filterkeycomp
                    .filterkeymarca = filterkeymarca
                    .filterkeytype = filterkeytype
                    .filterkeygroup = filterkeygroup
                    .filterkeyprod = filterkeyprod
                    .filterkeyAnocol = filterkeyAnoCol
                    .filterkeypackage = filterkeyPackage
                    .filtergrid = filtergrid
                    .filtermark = Text1.Text
                    .MdiParent = Me.MdiParent
                    .Show()
                End With
                Cursor.Current = Cursors.Default
            Case "vendasportomesfullano1"
                Me.SuspendLayout()
                Dim formgrid As New FormGridPortoMes
                With formgrid
                    .vardatabase = varDatabase
                    .vartabela = "vendasportomesfullano1"
                    .filterkeydir = filterkeydir
                    .filterkeypais = filterkeypais
                    .filterkeycli = filterkeycli
                    .filterkeycomp = filterkeycomp
                    .filterkeymarca = filterkeymarca
                    .filterkeytype = filterkeytype
                    .filterkeygroup = filterkeygroup
                    .filterkeyprod = filterkeyprod
                    .filterkeyAnocol = filterkeyAnoCol
                    .filterkeypackage = filterkeyPackage
                    .filtergrid = filtergrid
                    .filtermark = Text1.Text
                    .MdiParent = Me.MdiParent
                    .Show()
                End With
                Cursor.Current = Cursors.Default
            Case "vendasportohistfull"
                Dim formgrid As New FormGridPortoHist
                With formgrid
                    .filterkeydir = filterkeydir
                    .filterkeypais = filterkeypais
                    .filterkeycli = filterkeycli
                    .filterkeycomp = filterkeycomp
                    .filterkeymarca = filterkeymarca
                    .filterkeytype = filterkeytype
                    .filterkeygroup = filterkeygroup
                    .filterkeyprod = filterkeyprod
                    .filterkeyAnocol = filterkeyAnoCol
                    .filterkeypackage = filterkeyPackage
                    .filtergrid = filtergrid
                    .filtermark = Text1.Text
                    .MdiParent = Me.MdiParent
                    .Show()
                End With
                Cursor.Current = Cursors.Default
            Case "vendasmadeiramesfull"
                Dim formgrid As New FormGridMadMes
                With formgrid
                    .varDatabase = varDatabase
                    .filterkeydir = filterkeydir
                    .filterkeypais = filterkeypais
                    .filterkeycli = filterkeycli
                    .filterkeycomp = filterkeycomp
                    .filterkeytype = filterkeytype
                    .filterkeygroup = filterkeygroup
                    .filterkeyprod = filterkeyprod
                    .filtergrid = filtergrid
                    .filtermark = Text1.Text
                    .MdiParent = Me.MdiParent
                    .Show()
                End With
                Cursor.Current = Cursors.Default
            Case "vendasmadeirahistfull"
                Dim formgrid As New FormGridMadHist
                With formgrid
                    .filterkeydir = filterkeydir
                    .filterkeypais = filterkeypais
                    .filterkeycli = filterkeycli
                    .filterkeycomp = filterkeycomp
                    .filterkeytype = filterkeytype
                    .filterkeygroup = filterkeygroup
                    .filterkeyprod = filterkeyprod
                    .filtergrid = filtergrid
                    .filtermark = Text1.Text
                    .MdiParent = Me.MdiParent
                    .Show()
                End With
                Cursor.Current = Cursors.Default
        End Select

    End Sub
    Private Sub Command2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Command2.Click
        filtergrid = True
        Cursor.Current = Cursors.WaitCursor
        Select Case varTabela
            Case "vendasportomescomp"
                Dim formgrid As New FormComp
                With formgrid
                    .vardatabase = varDatabase
                    .filterkeydir = filterkeydir
                    .filterkeypais = filterkeypais
                    .filterkeycli = filterkeycli
                    .filterkeycomp = filterkeycomp
                    .filterkeymarca = filterkeymarca
                    .filterkeytype = filterkeytype
                    .filterkeygroup = filterkeygroup
                    .filterkeyprod = filterkeyprod
                    .filterkeyanocol = filterkeyAnoCol
                    .filterkeypackage = filterkeyPackage
                    .filtergrid = filtergrid
                    .filtermark = Text1.Text
                    .FormComp_Load()
                End With
                Cursor.Current = Cursors.Default


            Case "vendasportomesfullano1"
                Dim formgrid As New FormGridPortoMes
                With formgrid
                    .vardatabase = varDatabase
                    .vartabela = "vendasportomesfullano1"
                    .filterkeydir = filterkeydir
                    .filterkeypais = filterkeypais
                    .filterkeycli = filterkeycli
                    .filterkeycomp = filterkeycomp
                    .filterkeymarca = filterkeymarca
                    .filterkeytype = filterkeytype
                    .filterkeygroup = filterkeygroup
                    .filterkeyprod = filterkeyprod
                    .filterkeyAnocol = filterkeyAnoCol
                    .filterkeypackage = filterkeyPackage
                    .filtergrid = filtergrid
                    .filtermark = Text1.Text
                    .MdiParent = Me.MdiParent
                    .Show()
                End With
                Cursor.Current = Cursors.Default

            Case "vendasportomesfull"
                Dim formgrid As New FormGridPortoMes
                With formgrid
                    .vardatabase = varDatabase
                    .vartabela = "vendasportomesfull"
                    .filterkeydir = filterkeydir
                    .filterkeypais = filterkeypais
                    .filterkeycli = filterkeycli
                    .filterkeycomp = filterkeycomp
                    .filterkeymarca = filterkeymarca
                    .filterkeytype = filterkeytype
                    .filterkeygroup = filterkeygroup
                    .filterkeyprod = filterkeyprod
                    .filterkeyAnocol = filterkeyAnoCol
                    .filterkeypackage = filterkeyPackage
                    .filtergrid = filtergrid
                    .filtermark = Text1.Text
                    .MdiParent = Me.MdiParent
                    .Show()
                End With
                Cursor.Current = Cursors.Default
            Case "vendasportohistfull"
                Dim formgrid As New FormGridPortoHist
                With formgrid
                    .filterkeydir = filterkeydir
                    .filterkeypais = filterkeypais
                    .filterkeycli = filterkeycli
                    .filterkeycomp = filterkeycomp
                    .filterkeymarca = filterkeymarca
                    .filterkeytype = filterkeytype
                    .filterkeygroup = filterkeygroup
                    .filterkeyprod = filterkeyprod
                    .filterkeyanocol = filterkeyAnoCol
                    .filterkeypackage = filterkeyPackage
                    .filtergrid = filtergrid
                    .filtermark = Text1.Text
                    .MdiParent = Me.MdiParent
                    .Show()
                End With
                Cursor.Current = Cursors.Default
            Case "vendasmadeiramesfull"
                Dim formgrid As New FormGridMadMes
                With formgrid
                    .varDatabase = varDatabase
                    .filterkeydir = filterkeydir
                    .filterkeypais = filterkeypais
                    .filterkeycli = filterkeycli
                    .filterkeycomp = filterkeycomp
                    .filterkeytype = filterkeytype
                    .filterkeygroup = filterkeygroup
                    .filterkeyprod = filterkeyprod
                    .filtergrid = filtergrid
                    .filtermark = Text1.Text
                    .MdiParent = Me.MdiParent
                    .Show()
                End With
                Cursor.Current = Cursors.Default
            Case "vendasmadeirahistfull"
                Dim formgrid As New FormGridMadHist
                With formgrid
                    .filterkeydir = filterkeydir
                    .filterkeypais = filterkeypais
                    .filterkeycli = filterkeycli
                    .filterkeycomp = filterkeycomp
                    .filterkeytype = filterkeytype
                    .filterkeygroup = filterkeygroup
                    .filterkeyprod = filterkeyprod
                    .filtergrid = filtergrid
                    .filtermark = Text1.Text
                    .MdiParent = Me.MdiParent
                    .Show()
                End With
                Cursor.Current = Cursors.Default
        End Select

    End Sub
    Private Sub Command3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Command3.Click
        Me.Close()
    End Sub



    Private Sub TreeView1_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView1.AfterSelect

        If flagWork = True Or click1 = False Then Exit Sub
        flagWork = True
        Dim varstr As String
        'varstr = ""
        varstr = vbNullString
        Dim xyz As Integer
        For xyz = 1 To Len(e.Node.Text)
            If Mid$(e.Node.Text, xyz, 1) = "'" Then
                varstr = varstr + "_"
            Else
                varstr = varstr + Mid$(e.Node.Text, xyz, 1)
            End If
        Next xyz
        filterkeydir = IIf(e.Node.Text = "ALL" Or e.Node.Text = "Director", "%", varstr)
        filterkeypais = "%"
        filterkeycli = "%"
        filterkeycomp = "Company like '%'"
        filterkeymarca = "Marca like '%'"
        filterkeytype = "Tipo like '%'"
        filterkeygroup = "Grupo like '%'"
        filterkeyprod = "Subcat Like '%'"
        filterkeyAnoCol = "Anocol like '%'"
        filterkeyPackage = "embalagem like '%'"
        treefill(0)
        Text1.Text = vbNullString
        click1 = False
    End Sub
    Private Sub TreeView1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TreeView1.Click
        click1 = True
    End Sub

    Private Sub TreeView2_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView2.AfterSelect
        If flagWork = True Or click2 = False Then Exit Sub
        flagWork = True
        Dim varstr As String
        varstr = vbNullString
        Dim xyz As Integer
        For xyz = 1 To Len(e.Node.Text)
            If Mid$(e.Node.Text, xyz, 1) = "'" Then
                varstr = varstr + "_"
            Else
                varstr = varstr + Mid$(e.Node.Text, xyz, 1)
            End If
        Next xyz
        filterkeypais = IIf(e.Node.Text = "ALL" Or e.Node.Text = "Market", "%", varstr)
        filterkeycli = "%"
        filterkeycomp = "Company like '%'"
        filterkeymarca = "Marca like '%'"
        filterkeytype = "Tipo like '%'"
        filterkeygroup = "Grupo like '%'"
        filterkeyprod = "Subcat Like '%'"
        filterkeyAnoCol = "Anocol like '%'"
        filterkeyPackage = "embalagem like '%'"
        treefill(1)
        Text1.Text = vbNullString
        click2 = False
    End Sub
    Private Sub TreeView2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TreeView2.Click
        click2 = True
    End Sub

    Private Sub TreeView3_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView3.AfterSelect
        If flagWork = True Or click3 = False Then Exit Sub
        flagWork = True
        Dim varstr As String
        varstr = vbNullString
        Dim xyz As Integer
        For xyz = 1 To Len(e.Node.Text)
            If Mid$(e.Node.Text, xyz, 1) = "'" Then
                varstr = varstr + "''"
            Else
                varstr = varstr + Mid$(e.Node.Text, xyz, 1)
            End If
        Next xyz
        filterkeycli = IIf(e.Node.Text = "ALL" Or e.Node.Text = "Client", "%", varstr)
        filterkeycomp = "Company like '%'"
        filterkeymarca = "Marca like '%'"
        filterkeytype = "Tipo like '%'"
        filterkeygroup = "Grupo like '%'"
        filterkeyprod = "Subcat Like '%'"
        filterkeyAnoCol = "Anocol like '%'"
        filterkeyPackage = "embalagem like '%'"
        treefill(2)
        Text1.Text = vbNullString
        click3 = False
    End Sub
    Private Sub TreeView3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TreeView3.Click
        click3 = True
    End Sub


    Private Sub TreeView4_BeforeCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView4.BeforeCheck
        If e.Node.Text = "Company" Then e.Cancel() = True

    End Sub
    Private Sub TreeView4_AfterCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView4.AfterCheck
        If Not e.Node.Text = "ALL" And Not e.Action = TreeViewAction.ByMouse Then Exit Sub
        If Not e.Node.Text = "ALL" Then TreeView4.Nodes(0).Nodes(0).Checked = False : Exit Sub

        Dim xt As TreeNode
        If e.Node.Text = "ALL" And TreeView4.Nodes(0).Nodes(0).Checked Then
            For Each xt In TreeView4.Nodes(0).Nodes
                If Not xt.Text = "ALL" Then xt.Checked = False
            Next
        End If


        Dim varstr As String
        varstr = "Company LIKE '"
        'varstr = vbNullString
        For Each xt In TreeView4.Nodes(0).Nodes
            If xt.Checked = True Then

                varstr = varstr & IIf(xt.Text = "ALL", "%", xt.Text) & "' OR Company LIKE '"
            End If
        Next
        Try
            filterkeycomp = Microsoft.VisualBasic.Left(varstr, Len(varstr) - 18)
            filterkeymarca = "Marca like '%'"
            filterkeytype = "Tipo like '%'"
            filterkeygroup = "Grupo like '%'"
            filterkeyprod = "Subcat Like '%'"
            filterkeyAnoCol = "Anocol like '%'"
            filterkeyPackage = "embalagem like '%'"
            treefill(3)
        Catch
            TreeView4.Nodes(0).Nodes(0).Checked = True
        End Try

        Text1.Text = vbNullString

    End Sub
    Private Sub TreeView4_BeforeSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView4.BeforeSelect
        e.Cancel = True

    End Sub

    Private Sub TreeView5_BeforeCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView5.BeforeCheck
        If e.Node.Text = "Type" Then e.Cancel() = True

    End Sub
    Private Sub TreeView5_AfterCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView5.AfterCheck
        If Not e.Node.Text = "ALL" And Not e.Action = TreeViewAction.ByMouse Then Exit Sub
        If Not e.Node.Text = "ALL" Then TreeView5.Nodes(0).Nodes(0).Checked = False : Exit Sub

        Dim xt As TreeNode
        If e.Node.Text = "ALL" And TreeView5.Nodes(0).Nodes(0).Checked Then
            For Each xt In TreeView5.Nodes(0).Nodes
                If Not xt.Text = "ALL" Then xt.Checked = False
            Next
        End If

        Dim varstr As String
        varstr = "Tipo LIKE '"
        'varstr = vbNullString
        For Each xt In TreeView5.Nodes(0).Nodes
            If xt.Checked = True Then
                varstr = varstr & IIf(xt.Text = "ALL", "%", xt.Text) & "' OR tipo LIKE '"
            End If
        Next
        Try
            'filterkeymarca = Microsoft.VisualBasic.Left(varstr, Len(varstr) - 16)
            filterkeytype = Microsoft.VisualBasic.Left(varstr, Len(varstr) - 15)
            filterkeymarca = "Marca like '%'"
            filterkeygroup = "Grupo like '%'"
            filterkeyprod = "Subcat Like '%'"
            filterkeyAnoCol = "Anocol like '%'"
            filterkeyPackage = "embalagem like '%'"
            treefill(4)
        Catch
            TreeView5.Nodes(0).Nodes(0).Checked = True
        End Try

        Text1.Text = vbNullString
    End Sub
    Private Sub TreeView5_BeforeSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView5.BeforeSelect
        e.Cancel = True

    End Sub

    Private Sub TreeView6_BeforeCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView6.BeforeCheck
        If e.Node.Text = "Trademark" Then e.Cancel = True
    End Sub
    Private Sub TreeView6_AfterCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView6.AfterCheck
        If Not e.Node.Text = "ALL" And Not e.Action = TreeViewAction.ByMouse Then Exit Sub
        If Not e.Node.Text = "ALL" Then TreeView6.Nodes(0).Nodes(0).Checked = False : Exit Sub

        Dim xt As TreeNode
        If e.Node.Text = "ALL" And TreeView6.Nodes(0).Nodes(0).Checked Then
            For Each xt In TreeView6.Nodes(0).Nodes
                If Not xt.Text = "ALL" Then xt.Checked = False
            Next
        End If

        Dim varstr As String
        varstr = "Marca LIKE '"
        For Each xt In TreeView6.Nodes(0).Nodes
            If xt.Checked = True Then

                varstr = varstr & IIf(xt.Text = "ALL", "%", SQ(xt.Text)) & "' OR Marca LIKE '"

            End If
        Next
        Try
            filterkeymarca = Microsoft.VisualBasic.Left(varstr, Len(varstr) - 16)
            filterkeygroup = "Grupo like '%'"
            filterkeyprod = "Subcat Like '%'"
            filterkeyAnoCol = "Anocol like '%'"
            filterkeyPackage = "embalagem like '%'"
            treefill(5)
        Catch
            TreeView6.Nodes(0).Nodes(0).Checked = True
        End Try

        Text1.Text = vbNullString
    End Sub
    Private Sub TreeView6_BeforeSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView6.BeforeSelect
        e.Cancel = True
    End Sub

    Private Sub TreeView7_BeforeCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView7.BeforeCheck
        If e.Node.Text = "Group" Then e.Cancel() = True
    End Sub
    Private Sub TreeView7_AfterCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView7.AfterCheck
        If Not e.Node.Text = "ALL" And Not e.Action = TreeViewAction.ByMouse Then Exit Sub
        If Not e.Node.Text = "ALL" Then TreeView7.Nodes(0).Nodes(0).Checked = False : Exit Sub

        Dim xt As TreeNode
        If e.Node.Text = "ALL" And TreeView7.Nodes(0).Nodes(0).Checked Then
            For Each xt In TreeView7.Nodes(0).Nodes
                If Not xt.Text = "ALL" Then xt.Checked = False
            Next
        End If


        Dim varstr As String
        varstr = "grupo LIKE '"
        For Each xt In TreeView7.Nodes(0).Nodes
            If xt.Checked = True Then

                varstr = varstr & IIf(xt.Text = "ALL", "%", xt.Text) & "' OR grupo LIKE '"
            End If
        Next
        Try
            filterkeygroup = Microsoft.VisualBasic.Left(varstr, Len(varstr) - 16)
            filterkeyprod = "Subcat Like '%'"
            filterkeyAnoCol = "Anocol like '%'"
            filterkeyPackage = "embalagem like '%'"
            treefill(6)

        Catch
            TreeView7.Nodes(0).Nodes(0).Checked = True
        End Try

        Text1.Text = vbNullString
    End Sub
    Private Sub TreeView7_BeforeSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView7.BeforeSelect
        e.Cancel = True
    End Sub

    Private Sub TreeView8_BeforeCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView8.BeforeCheck
        If e.Node.Text = "Subcat" Then e.Cancel() = True

    End Sub
    Private Sub TreeView8_AfterCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView8.AfterCheck
        If Not e.Node.Text = "ALL" And Not e.Action = TreeViewAction.ByMouse Then Exit Sub
        If Not e.Node.Text = "ALL" Then TreeView8.Nodes(0).Nodes(0).Checked = False : Exit Sub

        Dim xt As TreeNode
        If e.Node.Text = "ALL" And TreeView8.Nodes(0).Nodes(0).Checked Then
            For Each xt In TreeView8.Nodes(0).Nodes
                If Not xt.Text = "ALL" Then xt.Checked = False
            Next
        End If

        Dim varstr As String
        varstr = "subcat LIKE '"
        For Each xt In TreeView8.Nodes(0).Nodes
            If xt.Checked = True Then
                varstr = varstr & IIf(xt.Text = "ALL", "%", xt.Text) & "' OR subcat LIKE '"
            End If
        Next
        Try
            filterkeyprod = Microsoft.VisualBasic.Left(varstr, Len(varstr) - 17)
            filterkeyAnoCol = "Anocol like '%'"
            filterkeyPackage = "embalagem like '%'"
            treefill(7)

        Catch
            TreeView8.Nodes(0).Nodes(0).Checked = True
        End Try

        Text1.Text = vbNullString
    End Sub
    Private Sub TreeView8_BeforeSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView8.BeforeSelect
        e.Cancel = True
    End Sub

    Private Sub TreeView9_BeforeCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView9.BeforeCheck
        If e.Node.Text = "VintageYear" Then e.Cancel() = True
    End Sub
    Private Sub TreeView9_AfterCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView9.AfterCheck
        If Not e.Node.Text = "ALL" And Not e.Action = TreeViewAction.ByMouse Then Exit Sub
        If Not e.Node.Text = "ALL" Then TreeView9.Nodes(0).Nodes(0).Checked = False : Exit Sub

        Dim xt As TreeNode
        If e.Node.Text = "ALL" And TreeView9.Nodes(0).Nodes(0).Checked Then
            For Each xt In TreeView9.Nodes(0).Nodes
                If Not xt.Text = "ALL" Then xt.Checked = False
            Next
        End If



        Dim varstr As String
        varstr = "anoCol LIKE '"
        For Each xt In TreeView9.Nodes(0).Nodes
            If xt.Checked = True Then
                varstr = varstr & IIf(xt.Text = "ALL", "%", xt.Text) & "' OR Anocol LIKE '"
            End If
        Next
        Try

            filterkeyAnoCol = Microsoft.VisualBasic.Left(varstr, Len(varstr) - 17)
            filterkeyPackage = "embalagem like '%'"
            treefill(8)

        Catch
            TreeView9.Nodes(0).Nodes(0).Checked = True
        End Try

        Text1.Text = vbNullString
    End Sub
    Private Sub TreeView9_BeforeSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView9.BeforeSelect
        e.Cancel = True
    End Sub

    Private Sub TreeView10_BeforeCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView10.BeforeCheck
        If e.Node.Text = "Package" Then e.Cancel() = True
    End Sub
    Private Sub TreeView10_AfterCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView10.AfterCheck
        If Not e.Node.Text = "ALL" And Not e.Action = TreeViewAction.ByMouse Then Exit Sub
        If Not e.Node.Text = "ALL" Then TreeView10.Nodes(0).Nodes(0).Checked = False : Exit Sub

        Dim xt As TreeNode
        If e.Node.Text = "ALL" And TreeView10.Nodes(0).Nodes(0).Checked Then
            For Each xt In TreeView10.Nodes(0).Nodes
                If Not xt.Text = "ALL" Then xt.Checked = False
            Next
        End If


        Dim varstr As String
        varstr = "embalagem LIKE '"
        For Each xt In TreeView10.Nodes(0).Nodes
            If xt.Checked = True Then
                varstr = varstr & IIf(xt.Text = "ALL", "%", xt.Text) & "' OR embalagem LIKE '"
            End If
        Next
        Try

            filterkeyPackage = Microsoft.VisualBasic.Left(varstr, Len(varstr) - 20)
            ' treefill(8)

        Catch
            TreeView10.Nodes(0).Nodes(0).Checked = True
        End Try

        Text1.Text = vbNullString
    End Sub
    Private Sub TreeView10_BeforeSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView10.BeforeSelect
        e.Cancel = True
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim formgrid As New FormGridPortoHist
        With formgrid
            .filterkeydir = filterkeydir
            .filterkeypais = filterkeypais
            .filterkeycli = filterkeycli
            .filterkeycomp = filterkeycomp
            .filterkeymarca = filterkeymarca
            .filterkeytype = filterkeytype
            .filterkeygroup = filterkeygroup
            .filterkeyprod = filterkeyprod
            .filterkeyanocol = filterkeyAnoCol
            .filterkeypackage = filterkeyPackage
            .Groupmarket = True
            .filtermark = Text1.Text
            .MdiParent = Me.MdiParent
            .Show()
        End With
        Cursor.Current = Cursors.Default

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim formgrid As New FormGridPortoHist
        With formgrid
            .filterkeydir = filterkeydir
            .filterkeypais = filterkeypais
            .filterkeycli = filterkeycli
            .filterkeycomp = filterkeycomp
            .filterkeymarca = filterkeymarca
            .filterkeytype = filterkeytype
            .filterkeygroup = filterkeygroup
            .filterkeyprod = filterkeyprod
            .filterkeyanocol = filterkeyAnoCol
            .filterkeypackage = filterkeyPackage
            .filtergrid = filtergrid
            .Grouppackage = True

            .filtermark = Text1.Text
            .MdiParent = Me.MdiParent
            .Show()
        End With
        Cursor.Current = Cursors.Default


    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim formgrid As New FormGridPortoHist
        With formgrid
            .filterkeydir = filterkeydir
            .filterkeypais = filterkeypais
            .filterkeycli = filterkeycli
            .filterkeycomp = filterkeycomp
            .filterkeymarca = filterkeymarca
            .filterkeytype = filterkeytype
            .filterkeygroup = filterkeygroup
            .filterkeyprod = filterkeyprod
            .filterkeyanocol = filterkeyAnoCol
            .filterkeypackage = filterkeyPackage
            .filtergrid = filtergrid

            .Groupproduct = True
            .filtermark = Text1.Text
            .MdiParent = Me.MdiParent
            .Show()
        End With
        Cursor.Current = Cursors.Default
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Button1.Visible = True Xor Button1.Visible
        Button2.Visible = True Xor Button2.Visible
        Button3.Visible = True Xor Button3.Visible

    End Sub

    Public Function SQ(ByVal str As String)
        SQ = Replace(str, "'", "''", 1, -1, vbTextCompare)
    End Function



End Class
